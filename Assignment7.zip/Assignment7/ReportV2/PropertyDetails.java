package ReportV2;

public class PropertyDetails {
    private String name;
    private String ownerName;
    private String location;

    public PropertyDetails(String name, String ownerName, String location) {
        this.name = name;
        this.ownerName = ownerName;
        this.location = location;
    }

    public String getName() {
        return name;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public String getLocation() {
        return location;
    }
}
