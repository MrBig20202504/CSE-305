package ReportV2;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        PropertyDetails details1 = new PropertyDetails("Apartment A", "John Doe", "City Center");
        PropertyDetails details2 = new PropertyDetails("House B", "Jane Smith", "Suburb");
        PropertyDetails details3 = new PropertyDetails("Condo C", "Bob Johnson", "Downtown");

        Property property1 = new Property(details1, 1500.0);
        Property property2 = new Property(details2, 2000.0);
        Property property3 = new Property(details3, 1800.0);

        FinancialReport financialReport = new FinancialReport("Monthly Rent Summary",
                List.of(property1, property2, property3));
        financialReport.generateReport();
    }
}
