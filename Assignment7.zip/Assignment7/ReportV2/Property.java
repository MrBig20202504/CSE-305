package ReportV2;

public class Property {
    private PropertyDetails details;
    private double rentAmount;

    public Property(PropertyDetails details, double rentAmount) {
        this.details = details;
        this.rentAmount = rentAmount;
    }

    public PropertyDetails getDetails() {
        return details;
    }

    public double getRentAmount() {
        return rentAmount;
    }

    public void printPropertyDetails() {
        System.out.println("Property: " + details.getName());
        System.out.println("Owner: " + details.getOwnerName());
        System.out.println("Location: " + details.getLocation());
        System.out.println("Rent Amount: $" + rentAmount);
    }
}
