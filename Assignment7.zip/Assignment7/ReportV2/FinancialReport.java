package ReportV2;

import java.util.List;

public class FinancialReport {
    private static final double PREMIUM_PROPERTY_THRESHOLD = 2000.0;
    private String reportTitle;
    private List<Property> properties;

    public FinancialReport(String reportTitle, List<Property> properties) {
        this.reportTitle = reportTitle;
        this.properties = properties;
    }

    public void generateReport() {
        double totalRent = 0;
        System.out.println("Financial Report: " + reportTitle);
        System.out.println("----------------------------");

        for (Property property : properties) {
            property.printPropertyDetails();
            totalRent += property.getRentAmount();

            String propertyType = getPropertyType(property.getRentAmount());
            System.out.println("Type: " + propertyType);

            double yearlyRent = calculateYearlyRent(property.getRentAmount());
            System.out.println("Yearly Rent: $" + yearlyRent);
            System.out.println("--------------------");
        }

        System.out.println("Total Rent Amount: $" + totalRent);
    }

    private String getPropertyType(double rentAmount) {
        return rentAmount > PREMIUM_PROPERTY_THRESHOLD ? "Premium Property" : "Standard Property";
    }

    private double calculateYearlyRent(double monthlyRent) {
        return monthlyRent * 12;
    }
}
