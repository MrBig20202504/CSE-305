package CommunicationManager_V2;

import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;

class MessageRepository {
    private final Map<String, List<Message>> inbox = new HashMap<>();

    public void storeMessage(Message message) {
        inbox.computeIfAbsent(message.getRecipient(), k -> new ArrayList<>()).add(message);
    }

    public List<Message> getMessagesForRecipient(String recipient) {
        return inbox.getOrDefault(recipient, new ArrayList<>());
    }
}
