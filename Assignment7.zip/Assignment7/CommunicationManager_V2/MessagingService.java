package CommunicationManager_V2;

import java.util.List;

class MessagingService {
    private final MessageRepository repository;

    public MessagingService(MessageRepository repository) {
        this.repository = repository;
    }

    public void sendMessage(String content, String sender, String recipient) {
        Message message = new Message(content, sender, recipient);
        repository.storeMessage(message);
    }

    public List<Message> getMessagesForRecipient(String recipient) {
        return repository.getMessagesForRecipient(recipient);
    }

    public void printAllMessages(List<Message> messages) {
        for (Message message : messages) {
            System.out.println("Recipient: " + message.getRecipient());
            System.out.println("Sender: " + message.getSender());
            System.out.println("Content: " + message.getContent());
        }
    }
}