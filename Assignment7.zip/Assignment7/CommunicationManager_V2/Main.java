package CommunicationManager_V2;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        MessageRepository messageRepository = new MessageRepository();
        MessagingService messagingService = new MessagingService(messageRepository);

        messagingService.sendMessage("Hello, tenant!", "Property Manager", "Tenant A");
        messagingService.sendMessage("Important notice: Rent due next week.", "Property Owner", "Tenant A");
        messagingService.sendMessage("Maintenance request received.", "Tenant A", "Property Manager");

        List<Message> tenantAMessages = messagingService.getMessagesForRecipient("Tenant A");

        messagingService.printAllMessages(tenantAMessages);

        Message detailedMessage = new Message("Test", "Sender", "Recipient");
        detailedMessage.printMessageDetails(true);
    }
}
